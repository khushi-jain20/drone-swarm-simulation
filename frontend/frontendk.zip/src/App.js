// frontend/src/App.jsx
import React, { useState, useEffect } from 'react'; // <-- Add useEffect
import { useSimulation } from './hooks/useSimulation';

import ControlPanel from './components/ControlPanel';
import SimulationScreen from './components/SimulationScreen';
import MetricsPanel from './components/MetricsPanel';
import EventLog from './components/EventLog';
import AnalysisPanel from './components/AnalysisPanel';
import DronePresetPanel from './components/DronePresetPanel';

function App() {
    const [loadedScenario, setLoadedScenario] = useState(null);
    const [worldDimensions, setWorldDimensions] = useState(null); // <-- State for dimensions
    const { data, isConnected, startGame, pauseGame, resumeGame, resetGame } = useSimulation();

    // --- NEW: Fetch world dimensions on component mount ---
    useEffect(() => {
        const fetchWorldConfig = async () => {
            try {
                const response = await fetch('http://localhost:8000/config/world');
                const config = await response.json();
                setWorldDimensions({
                    width: config.world_width,
                    height: config.world_height
                });
            } catch (error) {
                console.error("Failed to fetch world configuration:", error);
            }
        };
        fetchWorldConfig();
    }, []); // Empty dependency array means this runs only once on mount

    // --- UPDATED: Wait for dimensions before rendering ---
    if (!isConnected || !data?.simulation_state || !worldDimensions) {
        return (
            <div className="bg-gray-900 text-white h-screen flex items-center justify-center font-mono">
                <h1 className="text-2xl animate-pulse">
                    {isConnected ? "Awaiting Simulation Data..." : "Connecting to Server..."}
                </h1>
            </div>
        );
    }

    return (
        <div className="bg-gray-900 text-gray-200 min-h-screen font-mono flex flex-col p-4 gap-4">
            <header className="flex-shrink-0">
                <h1 className="text-3xl text-cyan-400 font-bold">Autonomous Drone Swarm Engagement</h1>
                <p>Connection: <span className={isConnected ? 'text-green-500' : 'text-red-500'}>{isConnected ? 'Connected' : 'Disconnected'}</span></p>
            </header>

            <main className="flex-grow flex gap-4 overflow-hidden">
                {/* Left Column */}
                <div className="w-1/5 flex flex-col gap-4">
                    <AnalysisPanel analysisData={data.analysis} />
                    <DronePresetPanel analysisData={data.analysis} />
                </div>

                {/* Center Column */}
                <div className="flex-grow flex flex-col gap-4 w-3/5">
                    <ControlPanel
                        status={data.simulation_state.status}
                        onStart={startGame} onPause={pauseGame} onResume={resumeGame} onReset={resetGame}
                        onScenarioLoad={setLoadedScenario}
                    />
                    <div className="flex-grow relative border-2 border-gray-700 rounded-lg">
                        {/* --- UPDATED: Pass dimensions as a prop --- */}
                        <SimulationScreen
                            drones={data.drones}
                            assets={data.assets}
                            visualEvents={data.visual_events}
                            worldDimensions={worldDimensions}
                        />
                    </div>
                </div>

                {/* Right Column */}
                <div className="w-1/5 flex flex-col gap-4">
                    <EventLog logs={data.event_log} />
                    <MetricsPanel metrics={data.metrics} />
                </div>
            </main>
        </div>
    );
}

export default App;