// src/components/DronePresetPanel.js
import React from 'react';

// This component now receives the live analysis data
const DronePresetPanel = ({ analysisData }) => {
    // Safely get the list of targets, default to an empty array
    const targets = analysisData?.coordination_targets ?? [];

    // --- 1. Group friendly drones by their enemy target ---
    // We use reduce to transform the flat list into a grouped object
    // e.g., { "E-GA1": ["F1", "F5"], "E-AA2": ["F3"] }
    const groupedTargets = targets.reduce((acc, target) => {
        const { source_id, target_id } = target;
        // If the enemy ID isn't a key in our accumulator yet, add it with an empty array
        if (!acc[target_id]) {
            acc[target_id] = [];
        }
        // Push the friendly drone's ID into the array for that enemy
        acc[target_id].push(source_id);
        return acc;
    }, {});

    // --- 2. Filter for actual swarms (more than one friendly per target) ---
    const swarms = Object.entries(groupedTargets).filter(
        ([enemyId, friendlies]) => friendlies.length > 1
    );

    return (
        <div className="bg-gray-800 p-4 rounded-lg h-1/2 flex flex-col">
            {/* --- 3. Update the title to reflect the new purpose --- */}
            <h2 className="text-xl font-bold mb-4 border-b border-gray-600 pb-2">Swarm Coordination</h2>
            <div className="overflow-y-auto">
                {swarms.length > 0 ? (
                    // --- 4. If swarms exist, map over them and display the info ---
                    swarms.map(([enemyId, friendlies]) => (
                        <div key={enemyId} className="mb-3">
                            <p className="font-bold">
                                Target: <span className="text-red-400">{enemyId}</span>
                            </p>
                            <p className="text-sm">
                                Engaged by: <span className="text-cyan-400">
                                    {/* Join the friendly IDs with a comma for a clean list */}
                                    {friendlies.map(id => id).join(', ')}
                                </span>
                            </p>
                        </div>
                    ))
                ) : (
                    // --- 5. If no swarms are active, show a placeholder message ---
                    <p className="text-gray-400">No coordinated swarms detected...</p>
                )}
            </div>
        </div>
    );
};

export default DronePresetPanel;