// src/components/Drone.js
import React, { useState } from 'react';
import friendlyDroneImg from '../assets/friendly_drone.png';
import enemyDroneImg from '../assets/enemy_drone.png';

const Drone = ({ drone, worldDimensions }) => {
    const [imageError, setImageError] = useState(false);
    const imageSrc = drone.team === 'friendly' ? friendlyDroneImg : enemyDroneImg;
    const imageSize = 48;

    const isMoving = drone.velocity && (drone.velocity.x !== 0 || drone.velocity.y !== 0);
    const rotationRad = isMoving ? Math.atan2(drone.velocity.y, drone.velocity.x) : 0;

    // --- 1. Main Container for Drone + Health Bar ---
    // This container is now what gets positioned on the screen.
    const containerStyle = {
        position: 'absolute',
        width: `${imageSize}px`,
        height: `${imageSize}px`,
        left: `calc(${(drone.position.x / worldDimensions.width) * 100}% - ${imageSize / 2}px)`,
        top: `calc(${(drone.position.y / worldDimensions.height) * 100}% - ${imageSize / 2}px)`,
        // The transition for movement is now on the container.
        transition: 'left 0.05s linear, top 0.05s linear',
    };
    
    // --- 2. Drone Image Style ---
    // The image itself is simpler, just handling rotation.
    const imageStyle = {
        width: '100%',
        height: '100%',
        transform: `rotate(${rotationRad}rad)`,
        transition: 'transform 0.1s linear',
    };

    // --- 3. Health Bar Styles ---
    // A dark background for the health bar.
    const healthBarBackgroundStyle = {
        position: 'absolute',
        // Position it just below the drone image.
        bottom: '-12px',
        left: '50%',
        transform: 'translateX(-50%)', // Center it horizontally.
        width: '40px',
        height: '6px',
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
        border: '1px solid #4B5563', // Dark grey border
        borderRadius: '3px',
    };

    // The actual health level, which shrinks as health decreases.
    const healthBarForegroundStyle = {
        height: '100%',
        // The width is the crucial part, based on drone.health.
        width: `${drone.health}%`,
        // Green for friendlies, a warning-orange for enemies.
        backgroundColor: drone.team === 'friendly' ? '#22C55E' : '#F97316',
        borderRadius: '2px',
        // Animate the width change for a smooth "damage" effect.
        transition: 'width 0.2s ease-out',
    };


    return (
        <div style={containerStyle}>
            {imageError ? (
                <div style={{...imageStyle, backgroundColor: drone.team === 'friendly' ? 'cyan' : '#ff3838', border: '2px solid white'}} />
            ) : (
                <img 
                    src={imageSrc} 
                    alt={drone.team} 
                    style={imageStyle} 
                    onError={() => setImageError(true)}
                />
            )}

            {/* --- 4. Render the Health Bar --- */}
            {/* We only show the health bar if the drone has taken damage to reduce clutter. */}
            
                <div style={healthBarBackgroundStyle}>
                    <div style={healthBarForegroundStyle}></div>
                </div>
            
        </div>
    );
};

export default Drone;