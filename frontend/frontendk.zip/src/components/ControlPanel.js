// src/components/ControlPanel.js
import React, { useState, useEffect } from 'react';

const ControlPanel = ({ status, onStart, onPause, onResume, onReset, onScenarioLoad }) => {
    const [scenarios, setScenarios] = useState([]);
    const [selectedScenario, setSelectedScenario] = useState('');

    // Function to send configuration changes to the backend
    const sendConfig = async (endpoint, value) => {
        try {
            await fetch(`http://localhost:8000/config/${endpoint}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(value),
            });
        } catch (error) {
            console.error(`Failed to set ${endpoint}:`, error);
        }
    };

    const setSpeed = (speed) => sendConfig('speed', { multiplier: speed });
    const setAiLevel = (level) => sendConfig('ai_level', { level: level });

    // Fetch the list of available scenarios when the component loads
    useEffect(() => {
        fetch('http://localhost:8000/api/scenarios')
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                setScenarios(data);
                if (data.length > 0) setSelectedScenario(data[0].id);
            })
            .catch(error => console.error("Failed to fetch scenarios:", error));
    }, []);

    const handleStart = () => {
        if (selectedScenario) {
            const scenarioInfo = scenarios.find(s => s.id === selectedScenario);
            // This now correctly calls the prop passed down from App.js
            if (onScenarioLoad) {
                onScenarioLoad(scenarioInfo);
            }
            onStart(selectedScenario);
        }
    };
    
    const isRunning = status === 'running';
    const isIdle = status === 'idle' || !status;

    return (
        <div className="bg-gray-800 p-4 rounded-lg flex flex-col gap-4">
            {/* Top row for simulation control */}
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <select 
                        value={selectedScenario} 
                        onChange={e => setSelectedScenario(e.target.value)}
                        className="bg-gray-700 border border-gray-600 rounded p-2"
                        disabled={!isIdle}
                    >
                        {scenarios.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                    <button onClick={handleStart} disabled={!isIdle} className="bg-green-600 hover:bg-green-500 px-4 py-2 rounded disabled:opacity-50">Start</button>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={onPause} disabled={!isRunning} className="bg-yellow-600 hover:bg-yellow-500 px-4 py-2 rounded disabled:opacity-50">Pause</button>
                    <button onClick={onResume} disabled={isRunning} className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded disabled:opacity-50">Resume</button>
                    <button onClick={onReset} className="bg-red-600 hover:bg-red-500 px-4 py-2 rounded">Reset</button>
                </div>
            </div>
            {/* Bottom row for configuration */}
            <div className="flex items-center justify-between border-t border-gray-700 pt-4">
                 <div className="flex items-center gap-2">
                    <span className="font-bold">AI Level:</span>
                    <button onClick={() => setAiLevel('basic')} className="bg-gray-600 hover:bg-gray-500 px-3 py-1 rounded">Basic</button>
                    <button onClick={() => setAiLevel('normal')} className="bg-gray-600 hover:bg-gray-500 px-3 py-1 rounded">Normal</button>
                    <button onClick={() => setAiLevel('advanced')} className="bg-gray-600 hover:bg-gray-500 px-3 py-1 rounded">Advanced</button>
                </div>
                <div className="flex items-center gap-2">
                    <span className="font-bold">Speed:</span>
                    <button onClick={() => setSpeed(0.5)} className="bg-gray-600 hover:bg-gray-500 px-3 py-1 rounded">0.5x</button>
                    <button onClick={() => setSpeed(1)} className="bg-gray-600 hover:bg-gray-500 px-3 py-1 rounded">1x</button>
                    <button onClick={() => setSpeed(2)} className="bg-gray-600 hover:bg-gray-500 px-3 py-1 rounded">2x</button>
                </div>
            </div>
        </div>
    );
};

export default ControlPanel;