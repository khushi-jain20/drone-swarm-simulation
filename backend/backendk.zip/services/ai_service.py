# backend/services/ai_service.py
from typing import List, Dict, Set
from schemas.common_schemas import Drone, Asset, Position
from services.physics_service import calculate_distance, calculate_time_to_intercept
from core import config
import random

# --- AI ROUTER (This is the main function called by the simulation) ---

def get_swarm_decisions(friendly_drones: List[Drone], enemy_drones: List[Drone], assets: List[Asset]) -> Dict[str, Dict]:
    """
    Acts as a router to call the appropriate AI logic based on the global config setting.
    """
    if config.AI_INTELLIGENCE_LEVEL == 'basic':
        return _get_basic_decisions(friendly_drones, enemy_drones)
    elif config.AI_INTELLIGENCE_LEVEL == 'advanced':
        return _get_advanced_decisions(friendly_drones, enemy_drones, assets)
    else: # Default to 'normal'
        return _get_normal_decisions(friendly_drones, enemy_drones, assets)

# ----------------------------------------------------------------------
# 🤖 --- LEVEL 1: BASIC AI ---
# ----------------------------------------------------------------------

def _get_basic_decisions(friendly_drones: List[Drone], enemy_drones: List[Drone]) -> Dict[str, Dict]:
    """
    Purely reactive, greedy algorithm. Each drone targets the absolute closest enemy.
    No coordination, no threat assessment, no self-preservation.
    """
    decisions = {}
    if not enemy_drones:
        return {f.id: {"status": "patrolling", "target_id": None} for f in friendly_drones}

    for f_drone in friendly_drones:
        closest_enemy = min(enemy_drones, key=lambda e: calculate_distance(f_drone.position, e.position))
        decisions[f_drone.id] = {"status": "engaging", "target_id": closest_enemy.id}
        
    return decisions

# ----------------------------------------------------------------------
# 🧠 --- LEVEL 2: NORMAL AI ---
# ----------------------------------------------------------------------

def _get_normal_threat_score(enemy: Drone, assets: List[Asset], friendly_drones: List[Drone]) -> float:
    """Calculates threat with simple deconfliction."""
    score = 1.0
    if enemy.type == 'ground_attack' and assets:
        min_dist_to_asset = min((calculate_distance(enemy.position, a.position) for a in assets), default=float('inf'))
        if min_dist_to_asset < config.THREATENING_RANGE * 1.5:
            score += 5000 * ((config.THREATENING_RANGE * 1.5 - min_dist_to_asset) / config.THREATENING_RANGE)
    
    # Local Deconfliction: de-prioritize enemies that are already targeted.
    num_targeting = sum(1 for f in friendly_drones if f.target_id == enemy.id)
    if num_targeting > 0:
        score /= (num_targeting * 5)
    return score

def _get_normal_decisions(friendly_drones: List[Drone], enemy_drones: List[Drone], assets: List[Asset]) -> Dict[str, Dict]:
    """
    Threat-based prioritization with local deconfliction. This is our previous "smart" AI.
    """
    decisions: Dict[str, Dict] = {}
    assigned_drones: Set[str] = set()
    enemy_map = {e.id: e for e in enemy_drones}
    if not enemy_drones:
        return {f.id: {"status": "patrolling", "target_id": None} for f in friendly_drones}

    # Step 1: Handle imminent threats to assets (Red Alert)
    red_alert_threats = [e for e in enemy_drones if e.type == 'ground_attack' and any(calculate_distance(e.position, a.position) <= config.THREATENING_RANGE for a in assets)]
    if red_alert_threats:
        red_alert_threats.sort(key=lambda e: min(calculate_distance(e.position, a.position) for a in assets))
        for threat in red_alert_threats:
            available = [f for f in friendly_drones if f.id not in assigned_drones]
            if not available: break
            best_interceptor = min(available, key=lambda f: calculate_time_to_intercept(f.position, threat.position, threat.velocity, config.FRIENDLY_DRONE_SPEED))
            decisions[best_interceptor.id] = {"status": "intercepting", "target_id": threat.id}
            assigned_drones.add(best_interceptor.id)

    # Step 2: Assign remaining drones based on threat score
    unassigned_drones = [f for f in friendly_drones if f.id not in assigned_drones]
    threat_scores = {e.id: _get_normal_threat_score(e, assets, friendly_drones) for e in enemy_drones}
    sorted_threats = sorted(threat_scores, key=threat_scores.get, reverse=True)

    for threat_id in sorted_threats:
        if not unassigned_drones: break
        if threat_id not in enemy_map: continue
        threat = enemy_map[threat_id]
        unassigned_drones.sort(key=lambda d: calculate_distance(d.position, threat.position))
        drone_to_assign = unassigned_drones.pop(0)
        decisions[drone_to_assign.id] = {"status": "engaging", "target_id": threat.id}
    
    return decisions

# ----------------------------------------------------------------------
# 🚀 --- LEVEL 3: ADVANCED AI ---
# ----------------------------------------------------------------------
SAFE_POINT = Position(x=config.WORLD_WIDTH / 2, y=config.WORLD_HEIGHT - 50)
CRITICAL_HEALTH_THRESHOLD = 35 # Drones below this health will retreat

def _get_advanced_threat_score(enemy: Drone, assets: List[Asset], friendly_drones: List[Drone]) -> float:
    """More sophisticated threat calculation for dynamic battlefield assessment."""
    score = 1.0
    if enemy.type == 'ground_attack' and assets:
        min_dist_to_asset = min((calculate_distance(enemy.position, a.position) for a in assets), default=float('inf'))
        if min_dist_to_asset < config.THREATENING_RANGE * 1.5:
            score += 10000 * ((config.THREATENING_RANGE * 1.5 - min_dist_to_asset) / config.THREATENING_RANGE)
    
    # Prioritize already damaged enemies to finish them off (killer instinct)
    if enemy.health < 100:
        score *= 1.5 + (100 - enemy.health) / 100 # Bonus increases as health gets lower

    # Superior Deconfliction: spread fire even more effectively.
    num_targeting = sum(1 for f in friendly_drones if f.target_id == enemy.id)
    if num_targeting > 0:
        score /= (num_targeting * 10)
    return score

def _get_advanced_decisions(friendly_drones: List[Drone], enemy_drones: List[Drone], assets: List[Asset]) -> Dict[str, Dict]:
    """
    Proactive, collaborative, and adaptive swarm intelligence.
    Includes self-preservation and superior target prioritization.
    """
    decisions: Dict[str, Dict] = {}
    assigned_drones: Set[str] = set()
    enemy_map = {e.id: e for e in enemy_drones}
    if not enemy_drones:
        return {f.id: {"status": "patrolling", "target_id": None} for f in friendly_drones}

    # Step 1: Self-Preservation - damaged drones retreat
    for f_drone in friendly_drones:
        if f_drone.health <= CRITICAL_HEALTH_THRESHOLD:
            decisions[f_drone.id] = {"status": "retreating", "target_id": "SAFE_POINT"}
            assigned_drones.add(f_drone.id)

    # Step 2: Red Alert (same as Normal, but only uses non-retreating drones)
    red_alert_threats = [e for e in enemy_drones if e.type == 'ground_attack' and any(calculate_distance(e.position, a.position) <= config.THREATENING_RANGE for a in assets)]
    if red_alert_threats:
        red_alert_threats.sort(key=lambda e: min(calculate_distance(e.position, a.position) for a in assets))
        for threat in red_alert_threats:
            available = [f for f in friendly_drones if f.id not in assigned_drones]
            if not available: break
            best_interceptor = min(available, key=lambda f: calculate_time_to_intercept(f.position, threat.position, threat.velocity, config.FRIENDLY_DRONE_SPEED))
            decisions[best_interceptor.id] = {"status": "intercepting", "target_id": threat.id}
            assigned_drones.add(best_interceptor.id)

    # Step 3: Dynamic Battlefield Assessment for remaining drones
    unassigned_drones = [f for f in friendly_drones if f.id not in assigned_drones]
    threat_scores = {e.id: _get_advanced_threat_score(e, assets, friendly_drones) for e in enemy_drones}
    sorted_threats = sorted(threat_scores, key=threat_scores.get, reverse=True)

    for threat_id in sorted_threats:
        if not unassigned_drones: break
        if threat_id not in enemy_map: continue
        threat = enemy_map[threat_id]
        unassigned_drones.sort(key=lambda d: calculate_distance(d.position, threat.position))
        drone_to_assign = unassigned_drones.pop(0)
        decisions[drone_to_assign.id] = {"status": "engaging", "target_id": threat.id}
    
    return decisions
    
# --- Enemy AI (Remains aggressive and straightforward) ---
def get_enemy_decisions(enemy_drones: List[Drone], friendly_drones: List[Drone], assets: List[Asset]) -> Dict[str, Dict]:
    # (This function remains unchanged)
    decisions = {}
    if not friendly_drones and not assets:
        return {e.id: {"status": "patrolling", "target_id": None} for e in enemy_drones}
    for enemy in enemy_drones:
        if enemy.type == 'ground_attack' and assets:
            closest_asset = min(assets, key=lambda a: calculate_distance(enemy.position, a.position))
            decisions[enemy.id] = {"status": "engaging", "target_id": closest_asset.id}
        elif friendly_drones:
            closest_friendly = min(friendly_drones, key=lambda f: calculate_distance(enemy.position, f.position))
            decisions[enemy.id] = {"status": "engaging", "target_id": closest_friendly.id}
        else:
            decisions[enemy.id] = {"status": "patrolling", "target_id": None}
    return decisions
