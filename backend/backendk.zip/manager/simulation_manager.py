import time, uuid, csv, os
from datetime import datetime
from collections import Counter, defaultdict
from typing import List, Dict, Optional

from schemas.common_schemas import Drone, Asset, Position, VisualEvent
from schemas.api_schemas import SimulationStreamData, AnalysisData, CoordinationTarget, SwarmStateSummary
from services import scenario_service, ai_service, physics_service
from services.ai_service import SAFE_POINT
from core import config

class SimulationManager:
    def __init__(self):
        self.reset()

    def reset(self):
        if hasattr(self, 'status') and self.status in ['running', 'paused', 'finished']:
            self._save_results_to_csv()
        self.status: str = "idle"
        self.start_time: float = 0.0
        self.scenario_id: Optional[str] = None
        self.friendly_drones: List[Drone] = []
        self.enemy_drones: List[Drone] = []
        self.assets: List[Asset] = []
        self.visual_events: List[VisualEvent] = []
        self.event_log: List[Dict] = []
        self.metrics: Dict = {}
        self.weapon_cooldowns: Dict[str, float] = {}
        # This correctly initializes the damage queue every time the simulation is reset.
        self.pending_damage: Dict[str, List[int]] = defaultdict(list)
        self._reset_metrics()

    def _reset_metrics(self):
        self.metrics = {"assets_saved": 0, "neutralizations": 0, "friendly_losses": 0}

    def start(self, scenario_id: str):
        self.reset()
        self.status = "running"
        self.start_time = time.time()
        self.scenario_id = scenario_id
        scenario = scenario_service.get_scenario(scenario_id)
        if not scenario:
            self.status = "idle"; return
        self.friendly_drones = [Drone(**d) for d in scenario["friendly_drones"]]
        self.enemy_drones = [Drone(**d) for d in scenario["enemy_drones"]]
        self.assets = [Asset(**a) for a in scenario["assets"]]
        self._reset_metrics()
        self.metrics['assets_saved'] = len(self.assets)
        self.log_event(f"Simulation started: {scenario['name']}")

    def pause(self):
        if self.status == 'running': self.status = 'paused'

    def resume(self):
        if self.status == 'paused': self.status = 'running'

    def update(self):
        effective_dt = float(config.DELTA_TIME * config.SPEED_MULTIPLIER)

        if self.status == "running":
            # 1. Apply damage from the *previous* frame first.
            self._apply_pending_damage()

            all_drones = self.friendly_drones + self.enemy_drones
            drone_map = {d.id: d for d in all_drones}
            asset_map = {a.id: a for a in self.assets}
            
            friendly_decisions = ai_service.get_swarm_decisions(self.friendly_drones, self.enemy_drones, self.assets)
            enemy_decisions = ai_service.get_enemy_decisions(self.enemy_drones, self.friendly_drones, self.assets)
            
            for drone_id, decision in {**friendly_decisions, **enemy_decisions}.items():
                drone = drone_map.get(drone_id)
                if drone:
                    drone.status = decision.get("status", drone.status)
                    drone.target_id = decision.get("target_id", drone.target_id)
            
            for drone in all_drones:
                drone_speed = config.FRIENDLY_DRONE_SPEED if drone.team == 'friendly' else config.ENEMY_DRONE_SPEED
                
                # Handle retreat logic for Advanced AI
                if drone.status == "retreating" and drone.target_id == "SAFE_POINT":
                    drone.position, drone.velocity = physics_service.move_towards(drone.position, SAFE_POINT, drone_speed, effective_dt)
                    continue # Skip other movement logic for this drone

                target = drone_map.get(drone.target_id) or asset_map.get(drone.target_id) if drone.target_id else None
                if drone.status in ["engaging", "intercepting"] and target:
                    intercept_point = physics_service.calculate_intercept_point(drone.position, target.position, getattr(target, 'velocity', None), drone_speed)
                    drone.position, drone.velocity = physics_service.move_towards(drone.position, intercept_point, drone_speed, effective_dt)
                else:
                    drone.velocity = Position(x=0.0, y=0.0)

            # 2. Calculate combat and queue up damage for the *next* frame.
            self._handle_combat()

            if not self.enemy_drones or not self.friendly_drones or all(asset.health <= 0 for asset in self.assets):
                self.status = "finished"
                self.log_event("Simulation finished.")

        return self.get_current_state()

    def _handle_combat(self):
        all_drones = self.friendly_drones + self.enemy_drones
        drone_map = {d.id: d for d in all_drones}
        now = time.time()
        
        for drone in all_drones:
            if drone.status == "engaging" and drone.target_id and (now - self.weapon_cooldowns.get(drone.id, 0) > config.WEAPON_COOLDOWN):
                target = drone_map.get(drone.target_id)
                if target and physics_service.calculate_distance(drone.position, target.position) <= config.FIRING_RANGE:
                    # Create the visual effect immediately.
                    self.visual_events.append(VisualEvent(id=str(uuid.uuid4()), type="weapon_fire", position=drone.position, target_position=target.position, ttl=0.25, team=drone.team))
                    # Queue the damage instead of applying it directly.
                    self.pending_damage[target.id].append(config.WEAPON_DAMAGE)
                    self.weapon_cooldowns[drone.id] = now
    
    def _apply_pending_damage(self):
        """Applies damage queued from the previous simulation tick."""
        if not self.pending_damage:
            return

        all_drones = self.friendly_drones + self.enemy_drones
        drone_map = {d.id: d for d in all_drones}
        asset_map = {a.id: a for a in self.assets}
        drones_to_remove, assets_to_remove = set(), set()

        for target_id, damage_list in self.pending_damage.items():
            total_damage = sum(damage_list)
            target = drone_map.get(target_id) or asset_map.get(target_id)

            if target:
                target.health -= total_damage
                if target.health <= 0:
                    self.log_event(f"{target.id} neutralized!")
                    self.visual_events.append(VisualEvent(id=str(uuid.uuid4()), type="neutralization", position=target.position, ttl=1.5, team=getattr(target, 'team', 'asset')))
                    if isinstance(target, Drone):
                        drones_to_remove.add(target.id)
                    else:
                        assets_to_remove.add(target.id)
        
        if drones_to_remove:
            for removed_id in drones_to_remove:
                removed_drone = drone_map.get(removed_id)
                if removed_drone:
                    if removed_drone.team == "friendly": self.metrics["friendly_losses"] += 1
                    else: self.metrics["neutralizations"] += 1
            self.friendly_drones = [d for d in self.friendly_drones if d.id not in drones_to_remove]
            self.enemy_drones = [d for d in self.enemy_drones if d.id not in drones_to_remove]

        if assets_to_remove:
            for asset_id in assets_to_remove:
                if asset_id in asset_map:
                    asset_map[asset_id].health = 0
            self.metrics["assets_saved"] = len([a for a in self.assets if a.health > 0])
        
        self.pending_damage.clear()

    def get_current_state(self) -> SimulationStreamData:
        sim_time = (time.time() - self.start_time) if self.start_time > 0 else 0
        effective_dt = float(config.DELTA_TIME * config.SPEED_MULTIPLIER)
        
        self.visual_events = [e for e in self.visual_events if e.ttl > 0]
        for e in self.visual_events: e.ttl -= effective_dt
        
        return SimulationStreamData(
            simulation_state={"status": self.status, "time": sim_time},
            drones=[d.dict() for d in self.friendly_drones + self.enemy_drones],
            assets=[a.dict() for a in self.assets],
            visual_events=[e.dict() for e in self.visual_events],
            metrics=self.metrics, event_log=self.event_log[-20:],
            analysis=self._get_analysis_data()
        )

    def _get_analysis_data(self) -> AnalysisData:
        drone_map = {d.id: d for d in self.friendly_drones + self.enemy_drones}
        targets = [CoordinationTarget(source_id=d.id, target_id=d.target_id, distance=int(physics_service.calculate_distance(d.position, drone_map[d.target_id].position))) for d in self.friendly_drones if getattr(d, 'target_id', None) and d.target_id in drone_map]
        swarm_summary = [SwarmStateSummary(status=s, count=c) for s, c in Counter(d.status for d in self.friendly_drones).items()]
        return AnalysisData(coordination_targets=targets, swarm_state=swarm_summary)

    def log_event(self, message: str):
        sim_time = (time.time() - self.start_time) if self.start_time > 0 else 0
        self.event_log.append({"time": round(sim_time, 1), "message": message})

    def _save_results_to_csv(self):
        if not self.scenario_id: return
        sim_time = (time.time() - self.start_time) if self.start_time > 0 else 0
        header = ["timestamp", "scenario_id", "sim_time_sec", "neutralizations", "friendly_losses", "assets_saved"]
        data = {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "scenario_id": self.scenario_id, "sim_time_sec": round(sim_time, 2), "neutralizations": self.metrics["neutralizations"], "friendly_losses": self.metrics["friendly_losses"], "assets_saved": len([a for a in self.assets if a.health > 0])}
        try:
            file_exists = os.path.isfile(config.RESULTS_CSV_PATH)
            with open(config.RESULTS_CSV_PATH, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=header)
                if not file_exists: writer.writeheader()
                writer.writerow(data)
        except IOError as e: print(f"[CSV Logger] Error: {e}")