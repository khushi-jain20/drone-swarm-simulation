# api/config_endpoints.py
from fastapi import APIRouter
from pydantic import BaseModel
from core import config

# --- THIS IS THE FIX ---
# We create Pydantic models to define the expected JSON structure
class SpeedSetting(BaseModel):
    multiplier: float

class AiLevelSetting(BaseModel):
    level: str

# --- ADD THIS NEW MODEL ---
class WorldConfig(BaseModel):
    world_width: int
    world_height: int
# -------------------------

router = APIRouter()

# --- ADD THIS NEW ENDPOINT ---
@router.get("/config/world", response_model=WorldConfig)
def get_world_config():
    """Provides the simulation's world dimensions to the frontend."""
    return {
        "world_width": config.WORLD_WIDTH,
        "world_height": config.WORLD_HEIGHT
    }
# ----------------------------

@router.post("/config/speed")
def set_speed(settings: SpeedSetting): # The endpoint now expects the SpeedSetting model
    """Set simulation speed multiplier (e.g., 0.5x, 1x, 2x)."""
    config.SPEED_MULTIPLIER = max(0.1, settings.multiplier)
    return {"status": "success", "speed_multiplier": config.SPEED_MULTIPLIER}

@router.post("/config/ai_level")
def set_ai_level(settings: AiLevelSetting): # The endpoint now expects the AiLevelSetting model
    """Set AI difficulty level: basic, normal, advanced, adaptive."""
    level = settings.level
    if level not in ("basic", "normal", "advanced", "adaptive"):
        return {"error": "invalid level"}, 400
    config.AI_INTELLIGENCE_LEVEL = level
    return {"status": "success", "ai_intelligence_level": config.AI_INTELLIGENCE_LEVEL}
